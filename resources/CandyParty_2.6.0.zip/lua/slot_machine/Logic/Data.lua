
--local g_test_table_ref={[1]=10, test1=5,}

Game_Data = 
{
--	data = SceneSlotMachine_Raider,
   name = "JAMES1",
  year = 221,

	[1]=10, test1=5,
}



function MultiplyNumbers(a, b) 
return a * b 
end

print("Game_Data ver.3465") --02.20