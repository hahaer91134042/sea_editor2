--[[
		�錢�������ݽű�, ���ϻ����߼��ű����ʹ��
]]---- Ver 0320.1
MahJongWays316000301={
  version = {
    data_type = "HUGA",
    ver = 2,
  },
  is_fa = false,
  bets = {
    bet = {
      3,
      10,
      30,
      90,
    },
    multi = {
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      10,
    },
    Base = 2000,
  },
  line_coef = 40,
  prize_den = 100,
  tick_range = {
    low = 1,
    high = 1,
  },
  objs = {
    {
      id = 1,
      name = "Wild",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
        cont6 = {},
        cont7 = {},
        cont8 = {},
        cont9 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {
        1,
      },
      line_mutex = {},
      disable_copy = 1,
    },
    {
      id = 2,
      name = "Bonus",
      icon = "",
      k = 1,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = true,
        cont1 = {},
        cont2 = {},
        cont3 = {
          {
            event = 4,
            param = 12,
          },
        },
        cont4 = {
          {
            event = 4,
            param = 14,
          },
        },
        cont5 = {
          {
            event = 4,
            param = 16,
          },
        },
        cont6 = {
          {
            event = 4,
            param = 18,
          },
        },
        cont7 = {
          {
            event = 4,
            param = 20,
          },
        },
        cont8 = {
          {
            event = 4,
            param = 22,
          },
        },
        cont9 = {
          {
            event = 4,
            param = 24,
          },
        },
        cont10 = {
          {
            event = 4,
            param = 26,
          },
        },
        cont11 = {
          {
            event = 4,
            param = 28,
          },
        },
        cont12 = {
          {
            event = 4,
            param = 30,
          },
        },
        cont13 = {
          {
            event = 4,
            param = 32,
          },
        },
        cont14 = {
          {
            event = 4,
            param = 34,
          },
        },
        cont15 = {
          {
            event = 4,
            param = 36,
          },
        },
        cont16 = {
          {
            event = 4,
            param = 38,
          },
        },
        cont17 = {
          {
            event = 4,
            param = 40,
          },
        },
        cont18 = {
          {
            event = 4,
            param = 42,
          },
        },
        cont19 = {
          {
            event = 4,
            param = 44,
          },
        },
        cont20 = {
          {
            event = 4,
            param = 46,
          },
        },
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 1,
    },
    {
      id = 3,
      name = "Green",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 75,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 300,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 500,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 5,
        high = 5,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 4,
      name = "Red",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 50,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 200,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 400,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 5,
      name = "Blue",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 40,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 100,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 300,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 6,
      name = "8W",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 30,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 75,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 200,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 7,
      name = "5o",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 20,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 50,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 100,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 8,
      name = "5i",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 20,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 50,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 100,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 9,
      name = "2o",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 10,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 25,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 50,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 10,
      name = "2i",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 10,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 25,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 50,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 11,
      name = "#Green",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        3,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,
    },
    {
      id = 12,
      name = "#Red",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        4,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,
    },
    {
      id = 13,
      name = "#Blue",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        5,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,
    },
    {
      id = 14,
      name = "#8W",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        6,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,
    },
    {
      id = 15,
      name = "#5o",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        7,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,	  
    },
    {
      id = 16,
      name = "#5i",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        8,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,
    },
    {
      id = 17,
      name = "#2o",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        9,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,
    },
    {
      id = 18,
      name = "#2i",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        10,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1, 
   },
  },
  groups = {},
  prize_multi = {
    1,
    2,
    3,
    5,
  },
  rolls = {
    line_count = 4,
    roll_count = 5,
    rolls = {
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 114,
          cur_total = 114,
        },
        {
          id = 3,
          drag = 450,
          cur_total = 564,
        },
        {
          id = 4,
          drag = 450,
          cur_total = 1014,
        },
        {
          id = 5,
          drag = 150,
          cur_total = 1164,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 1314,
        },
        {
          id = 7,
          drag = 450,
          cur_total = 1764,
        },
        {
          id = 8,
          drag = 450,
          cur_total = 2214,
        },
        {
          id = 9,
          drag = 150,
          cur_total = 2364,
        },
        {
          id = 10,
          drag = 150,
          cur_total = 2514,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 114,
          cur_total = 114,
        },
        {
          id = 3,
          drag = 450,
          cur_total = 564,
        },
        {
          id = 4,
          drag = 450,
          cur_total = 1014,
        },
        {
          id = 5,
          drag = 150,
          cur_total = 1164,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 1314,
        },
        {
          id = 7,
          drag = 450,
          cur_total = 1764,
        },
        {
          id = 8,
          drag = 450,
          cur_total = 2214,
        },
        {
          id = 9,
          drag = 150,
          cur_total = 2364,
        },
        {
          id = 10,
          drag = 150,
          cur_total = 2514,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 114,
          cur_total = 114,
        },
        {
          id = 3,
          drag = 450,
          cur_total = 564,
        },
        {
          id = 4,
          drag = 450,
          cur_total = 1014,
        },
        {
          id = 5,
          drag = 150,
          cur_total = 1164,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 1314,
        },
        {
          id = 7,
          drag = 450,
          cur_total = 1764,
        },
        {
          id = 8,
          drag = 450,
          cur_total = 2214,
        },
        {
          id = 9,
          drag = 150,
          cur_total = 2364,
        },
        {
          id = 10,
          drag = 150,
          cur_total = 2514,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 114,
          cur_total = 114,
        },
        {
          id = 3,
          drag = 450,
          cur_total = 564,
        },
        {
          id = 4,
          drag = 450,
          cur_total = 1014,
        },
        {
          id = 5,
          drag = 150,
          cur_total = 1164,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 1314,
        },
        {
          id = 7,
          drag = 450,
          cur_total = 1764,
        },
        {
          id = 8,
          drag = 450,
          cur_total = 2214,
        },
        {
          id = 9,
          drag = 150,
          cur_total = 2364,
        },
        {
          id = 10,
          drag = 150,
          cur_total = 2514,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 150,
          cur_total = 207,
        },
        {
          id = 4,
          drag = 150,
          cur_total = 357,
        },
        {
          id = 5,
          drag = 450,
          cur_total = 807,
        },
        {
          id = 6,
          drag = 450,
          cur_total = 1257,
        },
        {
          id = 7,
          drag = 150,
          cur_total = 1407,
        },
        {
          id = 8,
          drag = 150,
          cur_total = 1557,
        },
        {
          id = 9,
          drag = 450,
          cur_total = 2007,
        },
        {
          id = 10,
          drag = 450,
          cur_total = 2457,
        },
        {
          id = 11,
          drag = 40,
          cur_total = 2497,
        },
        {
          id = 12,
          drag = 40,
          cur_total = 2537,
        },
        {
          id = 13,
          drag = 120,
          cur_total = 2657,
        },
        {
          id = 14,
          drag = 120,
          cur_total = 2777,
        },
        {
          id = 15,
          drag = 40,
          cur_total = 2817,
        },
        {
          id = 16,
          drag = 40,
          cur_total = 2857,
        },
        {
          id = 17,
          drag = 120,
          cur_total = 2977,
        },
        {
          id = 18,
          drag = 120,
          cur_total = 3097,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 150,
          cur_total = 207,
        },
        {
          id = 4,
          drag = 150,
          cur_total = 357,
        },
        {
          id = 5,
          drag = 450,
          cur_total = 807,
        },
        {
          id = 6,
          drag = 450,
          cur_total = 1257,
        },
        {
          id = 7,
          drag = 150,
          cur_total = 1407,
        },
        {
          id = 8,
          drag = 150,
          cur_total = 1557,
        },
        {
          id = 9,
          drag = 450,
          cur_total = 2007,
        },
        {
          id = 10,
          drag = 450,
          cur_total = 2457,
        },
        {
          id = 11,
          drag = 40,
          cur_total = 2497,
        },
        {
          id = 12,
          drag = 40,
          cur_total = 2537,
        },
        {
          id = 13,
          drag = 120,
          cur_total = 2657,
        },
        {
          id = 14,
          drag = 120,
          cur_total = 2777,
        },
        {
          id = 15,
          drag = 40,
          cur_total = 2817,
        },
        {
          id = 16,
          drag = 40,
          cur_total = 2857,
        },
        {
          id = 17,
          drag = 120,
          cur_total = 2977,
        },
        {
          id = 18,
          drag = 120,
          cur_total = 3097,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 150,
          cur_total = 207,
        },
        {
          id = 4,
          drag = 150,
          cur_total = 357,
        },
        {
          id = 5,
          drag = 450,
          cur_total = 807,
        },
        {
          id = 6,
          drag = 450,
          cur_total = 1257,
        },
        {
          id = 7,
          drag = 150,
          cur_total = 1407,
        },
        {
          id = 8,
          drag = 150,
          cur_total = 1557,
        },
        {
          id = 9,
          drag = 450,
          cur_total = 2007,
        },
        {
          id = 10,
          drag = 450,
          cur_total = 2457,
        },
        {
          id = 11,
          drag = 40,
          cur_total = 2497,
        },
        {
          id = 12,
          drag = 40,
          cur_total = 2537,
        },
        {
          id = 13,
          drag = 120,
          cur_total = 2657,
        },
        {
          id = 14,
          drag = 120,
          cur_total = 2777,
        },
        {
          id = 15,
          drag = 40,
          cur_total = 2817,
        },
        {
          id = 16,
          drag = 40,
          cur_total = 2857,
        },
        {
          id = 17,
          drag = 120,
          cur_total = 2977,
        },
        {
          id = 18,
          drag = 120,
          cur_total = 3097,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 150,
          cur_total = 207,
        },
        {
          id = 4,
          drag = 150,
          cur_total = 357,
        },
        {
          id = 5,
          drag = 450,
          cur_total = 807,
        },
        {
          id = 6,
          drag = 450,
          cur_total = 1257,
        },
        {
          id = 7,
          drag = 150,
          cur_total = 1407,
        },
        {
          id = 8,
          drag = 150,
          cur_total = 1557,
        },
        {
          id = 9,
          drag = 450,
          cur_total = 2007,
        },
        {
          id = 10,
          drag = 450,
          cur_total = 2457,
        },
        {
          id = 11,
          drag = 40,
          cur_total = 2497,
        },
        {
          id = 12,
          drag = 40,
          cur_total = 2537,
        },
        {
          id = 13,
          drag = 120,
          cur_total = 2657,
        },
        {
          id = 14,
          drag = 120,
          cur_total = 2777,
        },
        {
          id = 15,
          drag = 40,
          cur_total = 2817,
        },
        {
          id = 16,
          drag = 40,
          cur_total = 2857,
        },
        {
          id = 17,
          drag = 120,
          cur_total = 2977,
        },
        {
          id = 18,
          drag = 120,
          cur_total = 3097,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 117,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 192,
        },
        {
          id = 5,
          drag = 105,
          cur_total = 297,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 447,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 747,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1047,
        },
        {
          id = 9,
          drag = 600,
          cur_total = 1647,
        },
        {
          id = 10,
          drag = 600,
          cur_total = 2247,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2263,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2283,
        },
        {
          id = 13,
          drag = 28,
          cur_total = 2311,
        },
        {
          id = 14,
          drag = 40,
          cur_total = 2351,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2431,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2511,
        },
        {
          id = 17,
          drag = 160,
          cur_total = 2671,
        },
        {
          id = 18,
          drag = 160,
          cur_total = 2831,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 117,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 192,
        },
        {
          id = 5,
          drag = 105,
          cur_total = 297,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 447,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 747,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1047,
        },
        {
          id = 9,
          drag = 600,
          cur_total = 1647,
        },
        {
          id = 10,
          drag = 600,
          cur_total = 2247,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2263,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2283,
        },
        {
          id = 13,
          drag = 28,
          cur_total = 2311,
        },
        {
          id = 14,
          drag = 40,
          cur_total = 2351,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2431,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2511,
        },
        {
          id = 17,
          drag = 160,
          cur_total = 2671,
        },
        {
          id = 18,
          drag = 160,
          cur_total = 2831,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 117,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 192,
        },
        {
          id = 5,
          drag = 105,
          cur_total = 297,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 447,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 747,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1047,
        },
        {
          id = 9,
          drag = 600,
          cur_total = 1647,
        },
        {
          id = 10,
          drag = 600,
          cur_total = 2247,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2263,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2283,
        },
        {
          id = 13,
          drag = 28,
          cur_total = 2311,
        },
        {
          id = 14,
          drag = 40,
          cur_total = 2351,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2431,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2511,
        },
        {
          id = 17,
          drag = 160,
          cur_total = 2671,
        },
        {
          id = 18,
          drag = 160,
          cur_total = 2831,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 117,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 192,
        },
        {
          id = 5,
          drag = 105,
          cur_total = 297,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 447,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 747,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1047,
        },
        {
          id = 9,
          drag = 600,
          cur_total = 1647,
        },
        {
          id = 10,
          drag = 600,
          cur_total = 2247,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2263,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2283,
        },
        {
          id = 13,
          drag = 28,
          cur_total = 2311,
        },
        {
          id = 14,
          drag = 40,
          cur_total = 2351,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2431,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2511,
        },
        {
          id = 17,
          drag = 160,
          cur_total = 2671,
        },
        {
          id = 18,
          drag = 160,
          cur_total = 2831,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 117,
        },
        {
          id = 4,
          drag = 90,
          cur_total = 207,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 507,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 807,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1107,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1407,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 1707,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 2007,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2023,
        },
        {
          id = 12,
          drag = 24,
          cur_total = 2047,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2127,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2207,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2287,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2367,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2447,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 2527,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 117,
        },
        {
          id = 4,
          drag = 90,
          cur_total = 207,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 507,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 807,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1107,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1407,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 1707,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 2007,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2023,
        },
        {
          id = 12,
          drag = 24,
          cur_total = 2047,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2127,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2207,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2287,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2367,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2447,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 2527,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 117,
        },
        {
          id = 4,
          drag = 90,
          cur_total = 207,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 507,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 807,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1107,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1407,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 1707,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 2007,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2023,
        },
        {
          id = 12,
          drag = 24,
          cur_total = 2047,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2127,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2207,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2287,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2367,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2447,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 2527,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 117,
        },
        {
          id = 4,
          drag = 90,
          cur_total = 207,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 507,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 807,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1107,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1407,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 1707,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 2007,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2023,
        },
        {
          id = 12,
          drag = 24,
          cur_total = 2047,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2127,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2207,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2287,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2367,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2447,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 2527,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 85,
          cur_total = 85,
        },
        {
          id = 3,
          drag = 120,
          cur_total = 205,
        },
        {
          id = 4,
          drag = 180,
          cur_total = 385,
        },
        {
          id = 5,
          drag = 225,
          cur_total = 610,
        },
        {
          id = 6,
          drag = 225,
          cur_total = 835,
        },
        {
          id = 7,
          drag = 225,
          cur_total = 1060,
        },
        {
          id = 8,
          drag = 225,
          cur_total = 1285,
        },
        {
          id = 9,
          drag = 225,
          cur_total = 1510,
        },
        {
          id = 10,
          drag = 225,
          cur_total = 1735,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 85,
          cur_total = 85,
        },
        {
          id = 3,
          drag = 120,
          cur_total = 205,
        },
        {
          id = 4,
          drag = 180,
          cur_total = 385,
        },
        {
          id = 5,
          drag = 225,
          cur_total = 610,
        },
        {
          id = 6,
          drag = 225,
          cur_total = 835,
        },
        {
          id = 7,
          drag = 225,
          cur_total = 1060,
        },
        {
          id = 8,
          drag = 225,
          cur_total = 1285,
        },
        {
          id = 9,
          drag = 225,
          cur_total = 1510,
        },
        {
          id = 10,
          drag = 225,
          cur_total = 1735,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 85,
          cur_total = 85,
        },
        {
          id = 3,
          drag = 120,
          cur_total = 205,
        },
        {
          id = 4,
          drag = 180,
          cur_total = 385,
        },
        {
          id = 5,
          drag = 225,
          cur_total = 610,
        },
        {
          id = 6,
          drag = 225,
          cur_total = 835,
        },
        {
          id = 7,
          drag = 225,
          cur_total = 1060,
        },
        {
          id = 8,
          drag = 225,
          cur_total = 1285,
        },
        {
          id = 9,
          drag = 225,
          cur_total = 1510,
        },
        {
          id = 10,
          drag = 225,
          cur_total = 1735,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 85,
          cur_total = 85,
        },
        {
          id = 3,
          drag = 120,
          cur_total = 205,
        },
        {
          id = 4,
          drag = 180,
          cur_total = 385,
        },
        {
          id = 5,
          drag = 225,
          cur_total = 610,
        },
        {
          id = 6,
          drag = 225,
          cur_total = 835,
        },
        {
          id = 7,
          drag = 225,
          cur_total = 1060,
        },
        {
          id = 8,
          drag = 225,
          cur_total = 1285,
        },
        {
          id = 9,
          drag = 225,
          cur_total = 1510,
        },
        {
          id = 10,
          drag = 225,
          cur_total = 1735,
        },
      },
    },
  },
  kick_out = {
    multiple = {
      {
        key_val = 1,
        weight = 100,
      },
    },
    quota = {},
    total = 100,
  },
  uc = {
    uc_type = "UC_MUTEX",
    total = 0,
    rolls = {
      {
        order = 16,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 14,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 12,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 10,
        relation = {},
        columncopy = {},
        uncopy = {},
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 0,
        uc = 100,
        total = 100,
      },
      {
        order = 26,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 30,
        uc = 70,
        total = 100,
      },
      {
        order = 24,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 30,
        uc = 70,
        total = 100,
      },
      {
        order = 22,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 30,
        uc = 70,
        total = 100,
      },
      {
        order = 20,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 30,
        uc = 70,
        total = 100,
      },
      {
        order = 36,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 16,
        col_cp_numerator = 0,
        uc_mutex_numerator = 34,
        uc = 50,
        total = 100,
      },
      {
        order = 34,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 16,
        col_cp_numerator = 0,
        uc_mutex_numerator = 34,
        uc = 50,
        total = 100,
      },
      {
        order = 32,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 16,
        col_cp_numerator = 0,
        uc_mutex_numerator = 34,
        uc = 50,
        total = 100,
      },
      {
        order = 30,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 16,
        col_cp_numerator = 0,
        uc_mutex_numerator = 34,
        uc = 50,
        total = 100,
      },
      {
        order = 46,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 21,
        col_cp_numerator = 0,
        uc_mutex_numerator = 29,
        uc = 50,
        total = 100,
      },
      {
        order = 44,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 21,
        col_cp_numerator = 0,
        uc_mutex_numerator = 29,
        uc = 50,
        total = 100,
      },
      {
        order = 42,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 21,
        col_cp_numerator = 0,
        uc_mutex_numerator = 29,
        uc = 50,
        total = 100,
      },
      {
        order = 40,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 21,
        col_cp_numerator = 0,
        uc_mutex_numerator = 29,
        uc = 50,
        total = 100,
      },
      {
        order = 56,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 26,
        col_cp_numerator = 0,
        uc_mutex_numerator = 24,
        uc = 50,
        total = 100,
      },
      {
        order = 54,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 26,
        col_cp_numerator = 0,
        uc_mutex_numerator = 24,
        uc = 50,
        total = 100,
      },
      {
        order = 52,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 26,
        col_cp_numerator = 0,
        uc_mutex_numerator = 24,
        uc = 50,
        total = 100,
      },
      {
        order = 50,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 26,
        col_cp_numerator = 0,
        uc_mutex_numerator = 24,
        uc = 50,
        total = 100,
      },
    },
    order = {
      4,
      3,
      2,
      1,
      8,
      7,
      6,
      5,
      12,
      11,
      10,
      9,
      16,
      15,
      14,
      13,
      20,
      19,
      18,
      17,
    },
  },
  sa = {
    items = {},
    total = 10,
  },
}
MahJongWays316000301_FreeSpin={
  obj_k = {
    100,
    100,
    100,
    100,
    100,
    100,
    100,
    100,
    100,
    100,
    100,
  },
  prize_multi = {
    2,
    4,
    6,
    10,
  },
  groups = {},
  rolls = {
    line_count = 4,
    roll_count = 5,
    rolls = {
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 60,
          cur_total = 60,
        },
        {
          id = 3,
          drag = 450,
          cur_total = 510,
        },
        {
          id = 4,
          drag = 450,
          cur_total = 960,
        },
        {
          id = 5,
          drag = 75,
          cur_total = 1035,
        },
        {
          id = 6,
          drag = 75,
          cur_total = 1110,
        },
        {
          id = 7,
          drag = 450,
          cur_total = 1560,
        },
        {
          id = 8,
          drag = 450,
          cur_total = 2010,
        },
        {
          id = 9,
          drag = 75,
          cur_total = 2085,
        },
        {
          id = 10,
          drag = 75,
          cur_total = 2160,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 60,
          cur_total = 60,
        },
        {
          id = 3,
          drag = 450,
          cur_total = 510,
        },
        {
          id = 4,
          drag = 450,
          cur_total = 960,
        },
        {
          id = 5,
          drag = 75,
          cur_total = 1035,
        },
        {
          id = 6,
          drag = 75,
          cur_total = 1110,
        },
        {
          id = 7,
          drag = 450,
          cur_total = 1560,
        },
        {
          id = 8,
          drag = 450,
          cur_total = 2010,
        },
        {
          id = 9,
          drag = 75,
          cur_total = 2085,
        },
        {
          id = 10,
          drag = 75,
          cur_total = 2160,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 60,
          cur_total = 60,
        },
        {
          id = 3,
          drag = 450,
          cur_total = 510,
        },
        {
          id = 4,
          drag = 450,
          cur_total = 960,
        },
        {
          id = 5,
          drag = 75,
          cur_total = 1035,
        },
        {
          id = 6,
          drag = 75,
          cur_total = 1110,
        },
        {
          id = 7,
          drag = 450,
          cur_total = 1560,
        },
        {
          id = 8,
          drag = 450,
          cur_total = 2010,
        },
        {
          id = 9,
          drag = 75,
          cur_total = 2085,
        },
        {
          id = 10,
          drag = 75,
          cur_total = 2160,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 60,
          cur_total = 60,
        },
        {
          id = 3,
          drag = 450,
          cur_total = 510,
        },
        {
          id = 4,
          drag = 450,
          cur_total = 960,
        },
        {
          id = 5,
          drag = 75,
          cur_total = 1035,
        },
        {
          id = 6,
          drag = 75,
          cur_total = 1110,
        },
        {
          id = 7,
          drag = 450,
          cur_total = 1560,
        },
        {
          id = 8,
          drag = 450,
          cur_total = 2010,
        },
        {
          id = 9,
          drag = 75,
          cur_total = 2085,
        },
        {
          id = 10,
          drag = 75,
          cur_total = 2160,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 30,
          cur_total = 30,
        },
        {
          id = 3,
          drag = 75,
          cur_total = 105,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 180,
        },
        {
          id = 5,
          drag = 450,
          cur_total = 630,
        },
        {
          id = 6,
          drag = 450,
          cur_total = 1080,
        },
        {
          id = 7,
          drag = 75,
          cur_total = 1155,
        },
        {
          id = 8,
          drag = 75,
          cur_total = 1230,
        },
        {
          id = 9,
          drag = 450,
          cur_total = 1680,
        },
        {
          id = 10,
          drag = 450,
          cur_total = 2130,
        },
        {
          id = 11,
          drag = 20,
          cur_total = 2150,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2170,
        },
        {
          id = 13,
          drag = 120,
          cur_total = 2290,
        },
        {
          id = 14,
          drag = 120,
          cur_total = 2410,
        },
        {
          id = 15,
          drag = 20,
          cur_total = 2430,
        },
        {
          id = 16,
          drag = 20,
          cur_total = 2450,
        },
        {
          id = 17,
          drag = 120,
          cur_total = 2570,
        },
        {
          id = 18,
          drag = 120,
          cur_total = 2690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 30,
          cur_total = 30,
        },
        {
          id = 3,
          drag = 75,
          cur_total = 105,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 180,
        },
        {
          id = 5,
          drag = 450,
          cur_total = 630,
        },
        {
          id = 6,
          drag = 450,
          cur_total = 1080,
        },
        {
          id = 7,
          drag = 75,
          cur_total = 1155,
        },
        {
          id = 8,
          drag = 75,
          cur_total = 1230,
        },
        {
          id = 9,
          drag = 450,
          cur_total = 1680,
        },
        {
          id = 10,
          drag = 450,
          cur_total = 2130,
        },
        {
          id = 11,
          drag = 20,
          cur_total = 2150,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2170,
        },
        {
          id = 13,
          drag = 120,
          cur_total = 2290,
        },
        {
          id = 14,
          drag = 120,
          cur_total = 2410,
        },
        {
          id = 15,
          drag = 20,
          cur_total = 2430,
        },
        {
          id = 16,
          drag = 20,
          cur_total = 2450,
        },
        {
          id = 17,
          drag = 120,
          cur_total = 2570,
        },
        {
          id = 18,
          drag = 120,
          cur_total = 2690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 30,
          cur_total = 30,
        },
        {
          id = 3,
          drag = 75,
          cur_total = 105,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 180,
        },
        {
          id = 5,
          drag = 450,
          cur_total = 630,
        },
        {
          id = 6,
          drag = 450,
          cur_total = 1080,
        },
        {
          id = 7,
          drag = 75,
          cur_total = 1155,
        },
        {
          id = 8,
          drag = 75,
          cur_total = 1230,
        },
        {
          id = 9,
          drag = 450,
          cur_total = 1680,
        },
        {
          id = 10,
          drag = 450,
          cur_total = 2130,
        },
        {
          id = 11,
          drag = 20,
          cur_total = 2150,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2170,
        },
        {
          id = 13,
          drag = 120,
          cur_total = 2290,
        },
        {
          id = 14,
          drag = 120,
          cur_total = 2410,
        },
        {
          id = 15,
          drag = 20,
          cur_total = 2430,
        },
        {
          id = 16,
          drag = 20,
          cur_total = 2450,
        },
        {
          id = 17,
          drag = 120,
          cur_total = 2570,
        },
        {
          id = 18,
          drag = 120,
          cur_total = 2690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 30,
          cur_total = 30,
        },
        {
          id = 3,
          drag = 75,
          cur_total = 105,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 180,
        },
        {
          id = 5,
          drag = 450,
          cur_total = 630,
        },
        {
          id = 6,
          drag = 450,
          cur_total = 1080,
        },
        {
          id = 7,
          drag = 75,
          cur_total = 1155,
        },
        {
          id = 8,
          drag = 75,
          cur_total = 1230,
        },
        {
          id = 9,
          drag = 450,
          cur_total = 1680,
        },
        {
          id = 10,
          drag = 450,
          cur_total = 2130,
        },
        {
          id = 11,
          drag = 20,
          cur_total = 2150,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2170,
        },
        {
          id = 13,
          drag = 120,
          cur_total = 2290,
        },
        {
          id = 14,
          drag = 120,
          cur_total = 2410,
        },
        {
          id = 15,
          drag = 20,
          cur_total = 2430,
        },
        {
          id = 16,
          drag = 20,
          cur_total = 2450,
        },
        {
          id = 17,
          drag = 120,
          cur_total = 2570,
        },
        {
          id = 18,
          drag = 120,
          cur_total = 2690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 30,
          cur_total = 30,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 90,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 165,
        },
        {
          id = 5,
          drag = 105,
          cur_total = 270,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 420,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 720,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1020,
        },
        {
          id = 9,
          drag = 600,
          cur_total = 1620,
        },
        {
          id = 10,
          drag = 600,
          cur_total = 2220,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2236,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2256,
        },
        {
          id = 13,
          drag = 28,
          cur_total = 2284,
        },
        {
          id = 14,
          drag = 40,
          cur_total = 2324,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2404,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2484,
        },
        {
          id = 17,
          drag = 160,
          cur_total = 2644,
        },
        {
          id = 18,
          drag = 160,
          cur_total = 2804,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 30,
          cur_total = 30,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 90,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 165,
        },
        {
          id = 5,
          drag = 105,
          cur_total = 270,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 420,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 720,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1020,
        },
        {
          id = 9,
          drag = 600,
          cur_total = 1620,
        },
        {
          id = 10,
          drag = 600,
          cur_total = 2220,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2236,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2256,
        },
        {
          id = 13,
          drag = 28,
          cur_total = 2284,
        },
        {
          id = 14,
          drag = 40,
          cur_total = 2324,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2404,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2484,
        },
        {
          id = 17,
          drag = 160,
          cur_total = 2644,
        },
        {
          id = 18,
          drag = 160,
          cur_total = 2804,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 30,
          cur_total = 30,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 90,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 165,
        },
        {
          id = 5,
          drag = 105,
          cur_total = 270,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 420,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 720,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1020,
        },
        {
          id = 9,
          drag = 600,
          cur_total = 1620,
        },
        {
          id = 10,
          drag = 600,
          cur_total = 2220,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2236,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2256,
        },
        {
          id = 13,
          drag = 28,
          cur_total = 2284,
        },
        {
          id = 14,
          drag = 40,
          cur_total = 2324,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2404,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2484,
        },
        {
          id = 17,
          drag = 160,
          cur_total = 2644,
        },
        {
          id = 18,
          drag = 160,
          cur_total = 2804,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 30,
          cur_total = 30,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 90,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 165,
        },
        {
          id = 5,
          drag = 105,
          cur_total = 270,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 420,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 720,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1020,
        },
        {
          id = 9,
          drag = 600,
          cur_total = 1620,
        },
        {
          id = 10,
          drag = 600,
          cur_total = 2220,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2236,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2256,
        },
        {
          id = 13,
          drag = 28,
          cur_total = 2284,
        },
        {
          id = 14,
          drag = 40,
          cur_total = 2324,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2404,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2484,
        },
        {
          id = 17,
          drag = 160,
          cur_total = 2644,
        },
        {
          id = 18,
          drag = 160,
          cur_total = 2804,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 30,
          cur_total = 30,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 90,
        },
        {
          id = 4,
          drag = 90,
          cur_total = 180,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 480,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 780,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1080,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1380,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 1680,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 1980,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 1996,
        },
        {
          id = 12,
          drag = 24,
          cur_total = 2020,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2100,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2180,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2260,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2340,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2420,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 2500,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 30,
          cur_total = 30,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 90,
        },
        {
          id = 4,
          drag = 90,
          cur_total = 180,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 480,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 780,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1080,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1380,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 1680,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 1980,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 1996,
        },
        {
          id = 12,
          drag = 24,
          cur_total = 2020,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2100,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2180,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2260,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2340,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2420,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 2500,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 30,
          cur_total = 30,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 90,
        },
        {
          id = 4,
          drag = 90,
          cur_total = 180,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 480,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 780,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1080,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1380,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 1680,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 1980,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 1996,
        },
        {
          id = 12,
          drag = 24,
          cur_total = 2020,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2100,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2180,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2260,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2340,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2420,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 2500,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 30,
          cur_total = 30,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 90,
        },
        {
          id = 4,
          drag = 90,
          cur_total = 180,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 480,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 780,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1080,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1380,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 1680,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 1980,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 1996,
        },
        {
          id = 12,
          drag = 24,
          cur_total = 2020,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2100,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2180,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2260,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2340,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2420,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 2500,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 45,
          cur_total = 45,
        },
        {
          id = 3,
          drag = 120,
          cur_total = 165,
        },
        {
          id = 4,
          drag = 180,
          cur_total = 345,
        },
        {
          id = 5,
          drag = 225,
          cur_total = 570,
        },
        {
          id = 6,
          drag = 225,
          cur_total = 795,
        },
        {
          id = 7,
          drag = 225,
          cur_total = 1020,
        },
        {
          id = 8,
          drag = 225,
          cur_total = 1245,
        },
        {
          id = 9,
          drag = 225,
          cur_total = 1470,
        },
        {
          id = 10,
          drag = 225,
          cur_total = 1695,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 45,
          cur_total = 45,
        },
        {
          id = 3,
          drag = 120,
          cur_total = 165,
        },
        {
          id = 4,
          drag = 180,
          cur_total = 345,
        },
        {
          id = 5,
          drag = 225,
          cur_total = 570,
        },
        {
          id = 6,
          drag = 225,
          cur_total = 795,
        },
        {
          id = 7,
          drag = 225,
          cur_total = 1020,
        },
        {
          id = 8,
          drag = 225,
          cur_total = 1245,
        },
        {
          id = 9,
          drag = 225,
          cur_total = 1470,
        },
        {
          id = 10,
          drag = 225,
          cur_total = 1695,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 45,
          cur_total = 45,
        },
        {
          id = 3,
          drag = 120,
          cur_total = 165,
        },
        {
          id = 4,
          drag = 180,
          cur_total = 345,
        },
        {
          id = 5,
          drag = 225,
          cur_total = 570,
        },
        {
          id = 6,
          drag = 225,
          cur_total = 795,
        },
        {
          id = 7,
          drag = 225,
          cur_total = 1020,
        },
        {
          id = 8,
          drag = 225,
          cur_total = 1245,
        },
        {
          id = 9,
          drag = 225,
          cur_total = 1470,
        },
        {
          id = 10,
          drag = 225,
          cur_total = 1695,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 45,
          cur_total = 45,
        },
        {
          id = 3,
          drag = 120,
          cur_total = 165,
        },
        {
          id = 4,
          drag = 180,
          cur_total = 345,
        },
        {
          id = 5,
          drag = 225,
          cur_total = 570,
        },
        {
          id = 6,
          drag = 225,
          cur_total = 795,
        },
        {
          id = 7,
          drag = 225,
          cur_total = 1020,
        },
        {
          id = 8,
          drag = 225,
          cur_total = 1245,
        },
        {
          id = 9,
          drag = 225,
          cur_total = 1470,
        },
        {
          id = 10,
          drag = 225,
          cur_total = 1695,
        },
      },
    },
    rollsXXX = {
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 76,
          cur_total = 76,
        },
        {
          id = 3,
          drag = 300,
          cur_total = 376,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 676,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 976,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 1276,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1576,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1876,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 2176,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 2476,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 76,
          cur_total = 76,
        },
        {
          id = 3,
          drag = 300,
          cur_total = 376,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 676,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 976,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 1276,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1576,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1876,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 2176,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 2476,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 76,
          cur_total = 76,
        },
        {
          id = 3,
          drag = 300,
          cur_total = 376,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 676,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 976,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 1276,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1576,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1876,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 2176,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 2476,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 76,
          cur_total = 76,
        },
        {
          id = 3,
          drag = 300,
          cur_total = 376,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 676,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 976,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 1276,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1576,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1876,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 2176,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 2476,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 38,
          cur_total = 38,
        },
        {
          id = 3,
          drag = 300,
          cur_total = 338,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 638,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 938,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 1238,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1538,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1838,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 2138,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 2438,
        },
        {
          id = 11,
          drag = 80,
          cur_total = 2518,
        },
        {
          id = 12,
          drag = 80,
          cur_total = 2598,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2678,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2758,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2838,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2918,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2998,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 3078,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 38,
          cur_total = 38,
        },
        {
          id = 3,
          drag = 300,
          cur_total = 338,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 638,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 938,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 1238,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1538,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1838,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 2138,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 2438,
        },
        {
          id = 11,
          drag = 80,
          cur_total = 2518,
        },
        {
          id = 12,
          drag = 80,
          cur_total = 2598,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2678,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2758,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2838,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2918,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2998,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 3078,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 38,
          cur_total = 38,
        },
        {
          id = 3,
          drag = 300,
          cur_total = 338,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 638,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 938,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 1238,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1538,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1838,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 2138,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 2438,
        },
        {
          id = 11,
          drag = 80,
          cur_total = 2518,
        },
        {
          id = 12,
          drag = 80,
          cur_total = 2598,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2678,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2758,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2838,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2918,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2998,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 3078,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 38,
          cur_total = 38,
        },
        {
          id = 3,
          drag = 300,
          cur_total = 338,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 638,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 938,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 1238,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1538,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1838,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 2138,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 2438,
        },
        {
          id = 11,
          drag = 80,
          cur_total = 2518,
        },
        {
          id = 12,
          drag = 80,
          cur_total = 2598,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2678,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2758,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2838,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2918,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2998,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 3078,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 38,
          cur_total = 38,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 98,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 173,
        },
        {
          id = 5,
          drag = 105,
          cur_total = 278,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 428,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 728,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1028,
        },
        {
          id = 9,
          drag = 600,
          cur_total = 1628,
        },
        {
          id = 10,
          drag = 600,
          cur_total = 2228,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2244,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2264,
        },
        {
          id = 13,
          drag = 28,
          cur_total = 2292,
        },
        {
          id = 14,
          drag = 40,
          cur_total = 2332,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2412,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2492,
        },
        {
          id = 17,
          drag = 160,
          cur_total = 2652,
        },
        {
          id = 18,
          drag = 160,
          cur_total = 2812,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 38,
          cur_total = 38,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 98,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 173,
        },
        {
          id = 5,
          drag = 105,
          cur_total = 278,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 428,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 728,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1028,
        },
        {
          id = 9,
          drag = 600,
          cur_total = 1628,
        },
        {
          id = 10,
          drag = 600,
          cur_total = 2228,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2244,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2264,
        },
        {
          id = 13,
          drag = 28,
          cur_total = 2292,
        },
        {
          id = 14,
          drag = 40,
          cur_total = 2332,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2412,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2492,
        },
        {
          id = 17,
          drag = 160,
          cur_total = 2652,
        },
        {
          id = 18,
          drag = 160,
          cur_total = 2812,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 38,
          cur_total = 38,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 98,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 173,
        },
        {
          id = 5,
          drag = 105,
          cur_total = 278,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 428,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 728,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1028,
        },
        {
          id = 9,
          drag = 600,
          cur_total = 1628,
        },
        {
          id = 10,
          drag = 600,
          cur_total = 2228,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2244,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2264,
        },
        {
          id = 13,
          drag = 28,
          cur_total = 2292,
        },
        {
          id = 14,
          drag = 40,
          cur_total = 2332,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2412,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2492,
        },
        {
          id = 17,
          drag = 160,
          cur_total = 2652,
        },
        {
          id = 18,
          drag = 160,
          cur_total = 2812,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 38,
          cur_total = 38,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 98,
        },
        {
          id = 4,
          drag = 75,
          cur_total = 173,
        },
        {
          id = 5,
          drag = 105,
          cur_total = 278,
        },
        {
          id = 6,
          drag = 150,
          cur_total = 428,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 728,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1028,
        },
        {
          id = 9,
          drag = 600,
          cur_total = 1628,
        },
        {
          id = 10,
          drag = 600,
          cur_total = 2228,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2244,
        },
        {
          id = 12,
          drag = 20,
          cur_total = 2264,
        },
        {
          id = 13,
          drag = 28,
          cur_total = 2292,
        },
        {
          id = 14,
          drag = 40,
          cur_total = 2332,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2412,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2492,
        },
        {
          id = 17,
          drag = 160,
          cur_total = 2652,
        },
        {
          id = 18,
          drag = 160,
          cur_total = 2812,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 38,
          cur_total = 38,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 98,
        },
        {
          id = 4,
          drag = 90,
          cur_total = 188,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 488,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 788,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1088,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1388,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 1688,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 1988,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2004,
        },
        {
          id = 12,
          drag = 24,
          cur_total = 2028,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2108,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2188,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2268,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2348,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2428,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 2508,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 38,
          cur_total = 38,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 98,
        },
        {
          id = 4,
          drag = 90,
          cur_total = 188,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 488,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 788,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1088,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1388,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 1688,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 1988,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2004,
        },
        {
          id = 12,
          drag = 24,
          cur_total = 2028,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2108,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2188,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2268,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2348,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2428,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 2508,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 38,
          cur_total = 38,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 98,
        },
        {
          id = 4,
          drag = 90,
          cur_total = 188,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 488,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 788,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1088,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1388,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 1688,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 1988,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2004,
        },
        {
          id = 12,
          drag = 24,
          cur_total = 2028,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2108,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2188,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2268,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2348,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2428,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 2508,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 38,
          cur_total = 38,
        },
        {
          id = 3,
          drag = 60,
          cur_total = 98,
        },
        {
          id = 4,
          drag = 90,
          cur_total = 188,
        },
        {
          id = 5,
          drag = 300,
          cur_total = 488,
        },
        {
          id = 6,
          drag = 300,
          cur_total = 788,
        },
        {
          id = 7,
          drag = 300,
          cur_total = 1088,
        },
        {
          id = 8,
          drag = 300,
          cur_total = 1388,
        },
        {
          id = 9,
          drag = 300,
          cur_total = 1688,
        },
        {
          id = 10,
          drag = 300,
          cur_total = 1988,
        },
        {
          id = 11,
          drag = 16,
          cur_total = 2004,
        },
        {
          id = 12,
          drag = 24,
          cur_total = 2028,
        },
        {
          id = 13,
          drag = 80,
          cur_total = 2108,
        },
        {
          id = 14,
          drag = 80,
          cur_total = 2188,
        },
        {
          id = 15,
          drag = 80,
          cur_total = 2268,
        },
        {
          id = 16,
          drag = 80,
          cur_total = 2348,
        },
        {
          id = 17,
          drag = 80,
          cur_total = 2428,
        },
        {
          id = 18,
          drag = 80,
          cur_total = 2508,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 120,
          cur_total = 177,
        },
        {
          id = 4,
          drag = 180,
          cur_total = 357,
        },
        {
          id = 5,
          drag = 225,
          cur_total = 582,
        },
        {
          id = 6,
          drag = 225,
          cur_total = 807,
        },
        {
          id = 7,
          drag = 225,
          cur_total = 1032,
        },
        {
          id = 8,
          drag = 225,
          cur_total = 1257,
        },
        {
          id = 9,
          drag = 225,
          cur_total = 1482,
        },
        {
          id = 10,
          drag = 225,
          cur_total = 1707,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 120,
          cur_total = 177,
        },
        {
          id = 4,
          drag = 180,
          cur_total = 357,
        },
        {
          id = 5,
          drag = 225,
          cur_total = 582,
        },
        {
          id = 6,
          drag = 225,
          cur_total = 807,
        },
        {
          id = 7,
          drag = 225,
          cur_total = 1032,
        },
        {
          id = 8,
          drag = 225,
          cur_total = 1257,
        },
        {
          id = 9,
          drag = 225,
          cur_total = 1482,
        },
        {
          id = 10,
          drag = 225,
          cur_total = 1707,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 120,
          cur_total = 177,
        },
        {
          id = 4,
          drag = 180,
          cur_total = 357,
        },
        {
          id = 5,
          drag = 225,
          cur_total = 582,
        },
        {
          id = 6,
          drag = 225,
          cur_total = 807,
        },
        {
          id = 7,
          drag = 225,
          cur_total = 1032,
        },
        {
          id = 8,
          drag = 225,
          cur_total = 1257,
        },
        {
          id = 9,
          drag = 225,
          cur_total = 1482,
        },
        {
          id = 10,
          drag = 225,
          cur_total = 1707,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 57,
          cur_total = 57,
        },
        {
          id = 3,
          drag = 120,
          cur_total = 177,
        },
        {
          id = 4,
          drag = 180,
          cur_total = 357,
        },
        {
          id = 5,
          drag = 225,
          cur_total = 582,
        },
        {
          id = 6,
          drag = 225,
          cur_total = 807,
        },
        {
          id = 7,
          drag = 225,
          cur_total = 1032,
        },
        {
          id = 8,
          drag = 225,
          cur_total = 1257,
        },
        {
          id = 9,
          drag = 225,
          cur_total = 1482,
        },
        {
          id = 10,
          drag = 225,
          cur_total = 1707,
        },
      },
    },
  },
  uc = {
    uc_type = "UC_MUTEX",
    total = 0,
    rolls = {
      {
        order = 16,
        relation = {},
        columncopy = {},
        uncopy = {},
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 0,
        uc = 100,
        total = 100,
      },
      {
        order = 14,
        relation = {},
        columncopy = {},
        uncopy = {},
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 0,
        uc = 100,
        total = 100,
      },
      {
        order = 12,
        relation = {},
        columncopy = {},
        uncopy = {},
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 0,
        uc = 100,
        total = 100,
      },
      {
        order = 10,
        relation = {},
        columncopy = {},
        uncopy = {},
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 0,
        uc = 100,
        total = 100,
      },
      {
        order = 26,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 24,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 22,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 20,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 36,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 34,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 32,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 30,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 46,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 44,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 42,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 40,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 56,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 54,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 52,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 50,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
    },
    order = {
      4,
      3,
      2,
      1,
      8,
      7,
      6,
      5,
      12,
      11,
      10,
      9,
      16,
      15,
      14,
      13,
      20,
      19,
      18,
      17,
    },
  },
  kick_out = {
    multiple = {
      {
        key_val = 50,
        weight = 40,
      },
      {
        key_val = 100,
        weight = 60,
      },
      {
        key_val = 200,
        weight = 90,
      },
      {
        key_val = 2000,
        weight = 100,
      },
    },
    quota = {},
    total = 100,
  },
}