--[[
		�錢�������ݽű�, ���ϻ����߼��ű����ʹ��
]]---- Ver 0320.1
MahJongWays116000320={
  version = {
    data_type = "HUGA",
    ver = 2,
  },
  is_fa = false,
  bets = {
    bet = {
      3,
      10,
      30,
      90,
    },
    multi = {
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      10,
    },
    Base = 2000,
  },
  line_coef = 40,
  prize_den = 100,
  tick_range = {
    low = 1,
    high = 1,
  },
  objs = {
    {
      id = 1,
      name = "Wild",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
        cont6 = {},
        cont7 = {},
        cont8 = {},
        cont9 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {
        1,
      },
      line_mutex = {},
      disable_copy = 1,
    },
    {
      id = 2,
      name = "Bonus",
      icon = "",
      k = 1,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = true,
        cont1 = {},
        cont2 = {},
        cont3 = {
          {
            event = 4,
            param = 12,
          },
        },
        cont4 = {
          {
            event = 4,
            param = 14,
          },
        },
        cont5 = {
          {
            event = 4,
            param = 16,
          },
        },
        cont6 = {
          {
            event = 4,
            param = 18,
          },
        },
        cont7 = {
          {
            event = 4,
            param = 20,
          },
        },
        cont8 = {
          {
            event = 4,
            param = 22,
          },
        },
        cont9 = {
          {
            event = 4,
            param = 24,
          },
        },
        cont10 = {
          {
            event = 4,
            param = 26,
          },
        },
        cont11 = {
          {
            event = 4,
            param = 28,
          },
        },
        cont12 = {
          {
            event = 4,
            param = 30,
          },
        },
        cont13 = {
          {
            event = 4,
            param = 32,
          },
        },
        cont14 = {
          {
            event = 4,
            param = 34,
          },
        },
        cont15 = {
          {
            event = 4,
            param = 36,
          },
        },
        cont16 = {
          {
            event = 4,
            param = 38,
          },
        },
        cont17 = {
          {
            event = 4,
            param = 40,
          },
        },
        cont18 = {
          {
            event = 4,
            param = 42,
          },
        },
        cont19 = {
          {
            event = 4,
            param = 44,
          },
        },
        cont20 = {
          {
            event = 4,
            param = 46,
          },
        },
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 1,
    },
    {
      id = 3,
      name = "Green",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 75,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 300,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 500,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 5,
        high = 5,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 4,
      name = "Red",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 50,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 200,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 400,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 5,
      name = "Blue",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 40,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 100,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 300,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 6,
      name = "8W",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 30,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 75,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 200,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 7,
      name = "5o",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 20,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 50,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 100,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 8,
      name = "5i",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 20,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 50,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 100,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 9,
      name = "2o",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 10,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 25,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 50,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 10,
      name = "2i",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {
        {
          event = 0,
          param = 10,
        },
      },
      cont4 = {
        {
          event = 0,
          param = 25,
        },
      },
      cont5 = {
        {
          event = 0,
          param = 50,
        },
      },
      full = {},
      scatter_cnt = {},
      wild = {},
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      disable_copy = 0,
    },
    {
      id = 11,
      name = "#Green",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        3,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,
    },
    {
      id = 12,
      name = "#Red",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        4,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,
    },
    {
      id = 13,
      name = "#Blue",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        5,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,
    },
    {
      id = 14,
      name = "#8W",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        6,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,
    },
    {
      id = 15,
      name = "#5o",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        7,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,	  
    },
    {
      id = 16,
      name = "#5i",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        8,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,
    },
    {
      id = 17,
      name = "#2o",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        9,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1,
    },
    {
      id = 18,
      name = "#2i",
      icon = "",
      k = 100,
      cont2 = {},
      cont3 = {},
      cont4 = {},
      cont5 = {},
      full = {},
      scatter_cnt = {},
      wild = {
        10,
      },
      scatter = {
        flag = false,
        cont1 = {},
        cont2 = {},
        cont3 = {},
        cont4 = {},
        cont5 = {},
      },
      scatter_box = {
        flag = false,
        denominator = 0,
        low = 0,
        high = 0,
      },
      extra_rate = 0,
      mutex = {},
      roll_mutex = {},
      line_mutex = {},
      is_ChangeID = 1,
	  disable_copy = 1, 
   },
  },
  groups = {},
  prize_multi = {
    1,
    2,
    3,
    5,
  },
  rolls = {
    line_count = 4,
    roll_count = 5,
    rolls = {
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5041,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5041,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5041,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5041,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 950,
          cur_total = 4941,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5141,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5341,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5541,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5741,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 5941,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6141,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6341,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6541,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 950,
          cur_total = 4941,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5141,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5341,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5541,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5741,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 5941,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6141,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6341,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6541,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 950,
          cur_total = 4941,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5141,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5341,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5541,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5741,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 5941,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6141,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6341,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6541,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 950,
          cur_total = 4941,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5141,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5341,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5541,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5741,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 5941,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6141,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6341,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6541,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 950,
          cur_total = 4941,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5141,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5341,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5541,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5741,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 5941,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6141,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6341,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6541,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 950,
          cur_total = 4941,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5141,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5341,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5541,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5741,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 5941,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6141,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6341,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6541,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 950,
          cur_total = 4941,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5141,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5341,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5541,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5741,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 5941,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6141,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6341,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6541,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 950,
          cur_total = 4941,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5141,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5341,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5541,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5741,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 5941,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6141,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6341,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6541,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 950,
          cur_total = 4941,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5141,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5341,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5541,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5741,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 5941,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6141,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6341,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6541,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 950,
          cur_total = 4941,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5141,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5341,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5541,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5741,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 5941,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6141,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6341,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6541,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 950,
          cur_total = 4941,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5141,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5341,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5541,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5741,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 5941,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6141,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6341,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6541,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 950,
          cur_total = 4941,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5141,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5341,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5541,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5741,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 5941,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6141,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6341,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6541,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5041,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5041,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5041,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 1,
          cur_total = 1,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 541,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 841,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1241,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1741,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2341,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3091,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 3991,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5041,
        },
      },
    },
  },
  kick_out = {
    multiple = {},
    quota = {},
    total = 100,
  },
  uc = {
    uc_type = "UC_MUTEX",
    total = 0,
    rolls = {
      {
        order = 16,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 14,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 12,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 10,
        relation = {},
        columncopy = {},
        uncopy = {},
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 0,
        uc = 100,
        total = 100,
      },
      {
        order = 26,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 30,
        uc = 70,
        total = 100,
      },
      {
        order = 24,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 30,
        uc = 70,
        total = 100,
      },
      {
        order = 22,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 30,
        uc = 70,
        total = 100,
      },
      {
        order = 20,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 30,
        uc = 70,
        total = 100,
      },
      {
        order = 36,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 16,
        col_cp_numerator = 0,
        uc_mutex_numerator = 34,
        uc = 50,
        total = 100,
      },
      {
        order = 34,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 16,
        col_cp_numerator = 0,
        uc_mutex_numerator = 34,
        uc = 50,
        total = 100,
      },
      {
        order = 32,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 16,
        col_cp_numerator = 0,
        uc_mutex_numerator = 34,
        uc = 50,
        total = 100,
      },
      {
        order = 30,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 16,
        col_cp_numerator = 0,
        uc_mutex_numerator = 34,
        uc = 50,
        total = 100,
      },
      {
        order = 46,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 21,
        col_cp_numerator = 0,
        uc_mutex_numerator = 29,
        uc = 50,
        total = 100,
      },
      {
        order = 44,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 21,
        col_cp_numerator = 0,
        uc_mutex_numerator = 29,
        uc = 50,
        total = 100,
      },
      {
        order = 42,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 21,
        col_cp_numerator = 0,
        uc_mutex_numerator = 29,
        uc = 50,
        total = 100,
      },
      {
        order = 40,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 21,
        col_cp_numerator = 0,
        uc_mutex_numerator = 29,
        uc = 50,
        total = 100,
      },
      {
        order = 56,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 26,
        col_cp_numerator = 0,
        uc_mutex_numerator = 24,
        uc = 50,
        total = 100,
      },
      {
        order = 54,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 26,
        col_cp_numerator = 0,
        uc_mutex_numerator = 24,
        uc = 50,
        total = 100,
      },
      {
        order = 52,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 26,
        col_cp_numerator = 0,
        uc_mutex_numerator = 24,
        uc = 50,
        total = 100,
      },
      {
        order = 50,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 26,
        col_cp_numerator = 0,
        uc_mutex_numerator = 24,
        uc = 50,
        total = 100,
      },
    },
    order = {
      4,
      3,
      2,
      1,
      8,
      7,
      6,
      5,
      12,
      11,
      10,
      9,
      16,
      15,
      14,
      13,
      20,
      19,
      18,
      17,
    },
  },
  sa = {
    items = {},
    total = 10,
  },
}
MahJongWays116000320_FreeSpin={
  obj_k = {
    100,
    100,
    100,
    100,
    100,
    100,
    100,
    100,
    100,
    100,
    100,
  },
  prize_multi = {
    2,
    4,
    6,
    10,
  },
  groups = {},
  rolls = {
    line_count = 4,
    roll_count = 5,
    rolls = {
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5290,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5490,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5690,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5890,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 6090,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6290,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6490,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5290,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5490,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5690,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5890,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 6090,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6290,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6490,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5290,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5490,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5690,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5890,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 6090,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6290,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6490,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5290,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5490,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5690,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5890,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 6090,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6290,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6490,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5290,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5490,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5690,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5890,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 6090,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6290,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6490,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5290,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5490,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5690,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5890,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 6090,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6290,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6490,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5290,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5490,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5690,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5890,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 6090,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6290,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6490,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5290,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5490,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5690,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5890,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 6090,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6290,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6490,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5290,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5490,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5690,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5890,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 6090,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6290,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6490,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5290,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5490,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5690,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5890,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 6090,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6290,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6490,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5290,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5490,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5690,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5890,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 6090,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6290,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6490,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
        {
          id = 11,
          drag = 200,
          cur_total = 5290,
        },
        {
          id = 12,
          drag = 200,
          cur_total = 5490,
        },
        {
          id = 13,
          drag = 200,
          cur_total = 5690,
        },
        {
          id = 14,
          drag = 200,
          cur_total = 5890,
        },
        {
          id = 15,
          drag = 200,
          cur_total = 6090,
        },
        {
          id = 16,
          drag = 200,
          cur_total = 6290,
        },
        {
          id = 17,
          drag = 200,
          cur_total = 6490,
        },
        {
          id = 18,
          drag = 200,
          cur_total = 6690,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
      },
      {
        {
          id = 1,
          drag = 0,
          cur_total = 0,
        },
        {
          id = 2,
          drag = 50,
          cur_total = 50,
        },
        {
          id = 3,
          drag = 540,
          cur_total = 590,
        },
        {
          id = 4,
          drag = 300,
          cur_total = 890,
        },
        {
          id = 5,
          drag = 400,
          cur_total = 1290,
        },
        {
          id = 6,
          drag = 500,
          cur_total = 1790,
        },
        {
          id = 7,
          drag = 600,
          cur_total = 2390,
        },
        {
          id = 8,
          drag = 750,
          cur_total = 3140,
        },
        {
          id = 9,
          drag = 900,
          cur_total = 4040,
        },
        {
          id = 10,
          drag = 1050,
          cur_total = 5090,
        },
      },
    },
  },
  uc = {
    uc_type = "UC_MUTEX",
    total = 0,
    rolls = {
      {
        order = 16,
        relation = {},
        columncopy = {},
        uncopy = {},
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 0,
        uc = 100,
        total = 100,
      },
      {
        order = 14,
        relation = {},
        columncopy = {},
        uncopy = {},
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 0,
        uc = 100,
        total = 100,
      },
      {
        order = 12,
        relation = {},
        columncopy = {},
        uncopy = {},
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 0,
        uc = 100,
        total = 100,
      },
      {
        order = 10,
        relation = {},
        columncopy = {},
        uncopy = {},
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 0,
        uc = 100,
        total = 100,
      },
      {
        order = 26,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 24,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 22,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 20,
        relation = {},
        columncopy = {},
        uncopy = {
          {
            target = 1,
            weight = 0,
          },
          {
            target = 2,
            weight = 0,
          },
          {
            target = 3,
            weight = 0,
          },
          {
            target = 4,
            weight = 0,
          },
        },
        cp_numerator = 0,
        col_cp_numerator = 0,
        uc_mutex_numerator = 25,
        uc = 75,
        total = 100,
      },
      {
        order = 36,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 34,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 32,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 30,
        relation = {
          {
            target = 1,
            weight = 25,
          },
          {
            target = 2,
            weight = 25,
          },
          {
            target = 3,
            weight = 25,
          },
          {
            target = 4,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 5,
            weight = 0,
          },
          {
            target = 6,
            weight = 0,
          },
          {
            target = 7,
            weight = 0,
          },
          {
            target = 8,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 46,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 44,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 42,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 40,
        relation = {
          {
            target = 5,
            weight = 25,
          },
          {
            target = 6,
            weight = 25,
          },
          {
            target = 7,
            weight = 25,
          },
          {
            target = 8,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 9,
            weight = 0,
          },
          {
            target = 10,
            weight = 0,
          },
          {
            target = 11,
            weight = 0,
          },
          {
            target = 12,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 56,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 54,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 52,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
      {
        order = 50,
        relation = {
          {
            target = 9,
            weight = 25,
          },
          {
            target = 10,
            weight = 25,
          },
          {
            target = 11,
            weight = 25,
          },
          {
            target = 12,
            weight = 25,
          },
        },
        columncopy = {},
        uncopy = {
          {
            target = 13,
            weight = 0,
          },
          {
            target = 14,
            weight = 0,
          },
          {
            target = 15,
            weight = 0,
          },
          {
            target = 16,
            weight = 0,
          },
        },
        cp_numerator = 15,
        col_cp_numerator = 0,
        uc_mutex_numerator = 35,
        uc = 50,
        total = 100,
      },
    },
    order = {
      4,
      3,
      2,
      1,
      8,
      7,
      6,
      5,
      12,
      11,
      10,
      9,
      16,
      15,
      14,
      13,
      20,
      19,
      18,
      17,
    },
  },
  kick_out = {
    multiple = {},
    quota = {},
    total = 100,
  },
}